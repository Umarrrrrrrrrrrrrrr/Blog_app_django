from django.shortcuts import render, redirect
from .models import Post

# Create your views here.
def home(request):
    posts = Post.objects.all()
    return render(request, 'index.html', {'posts':posts})
    # return render(request, 'index.html')


def create_post(request):
    if request.method == "POST":
        title = request.POST.get("title")
        description = request.POST.get("description")
        new_post = Post(title = title, description = description)
        new_post.save()
        return redirect("home")
    return render(request, 'base.html')
